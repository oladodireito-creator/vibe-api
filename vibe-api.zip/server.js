const express = require('express');
require('dotenv').config();
const app = express();
app.use(express.json());
app.get('/', (req,res)=>res.json({status:"Vibe API running"}));
app.listen(process.env.PORT || 3000, ()=>console.log('Vibe API running'));
